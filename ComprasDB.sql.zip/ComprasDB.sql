USE [master]
GO
Create database [DBCompras]
GO
USE [DBCompras]
GO
/****** Object:  Table [dbo].[Articulos]    Script Date: 7/7/2023 8:50:46 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Articulos](
	[ArticuloId] [int] IDENTITY(1,1) NOT NULL,
	[Descripci�n] [varchar](100) NULL,
	[Marca] [varchar](50) NULL,
	[UnidadMedidaId] [int] NULL,
	[Existencia] [int] NULL,
	[Estado] [bit] NULL,
 CONSTRAINT [PK__Art�culo__3214EC07CF6459A3] PRIMARY KEY CLUSTERED 
(
	[ArticuloId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Departamentos]    Script Date: 7/7/2023 8:50:46 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Departamentos](
	[DepartamentoId] [int] IDENTITY(1,1) NOT NULL,
	[Nombre] [varchar](50) NULL,
	[Estado] [bit] NULL,
 CONSTRAINT [PK__Departam__787A433D0138D85F] PRIMARY KEY CLUSTERED 
(
	[DepartamentoId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Orden_de_compra]    Script Date: 7/7/2023 8:50:46 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Orden_de_compra](
	[Numero_de_orden] [int] IDENTITY(1,1) NOT NULL,
	[Fecha_orden] [date] NULL,
	[Estado] [bit] NULL,
	[Articulo] [int] NULL,
	[Cantidad] [int] NULL,
	[Unidad_de_medida] [int] NULL,
	[Costo] [decimal](18, 2) NULL,
	[UsuarioId] [int] NULL,
 CONSTRAINT [PK__Orden_de__B85220513498E3F8] PRIMARY KEY CLUSTERED 
(
	[Numero_de_orden] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Proveedores]    Script Date: 7/7/2023 8:50:46 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Proveedores](
	[ProveedorId] [int] IDENTITY(1,1) NOT NULL,
	[Cedula_RNC] [varchar](20) NULL,
	[Nombre_comercial] [varchar](100) NULL,
	[Estado] [bit] NULL,
 CONSTRAINT [PK__Proveedo__3214EC079849597D] PRIMARY KEY CLUSTERED 
(
	[ProveedorId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Unidades_de_medidas]    Script Date: 7/7/2023 8:50:46 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Unidades_de_medidas](
	[UnidadMedidaId] [int] IDENTITY(1,1) NOT NULL,
	[Descripcion] [varchar](50) NULL,
	[Estado] [bit] NULL,
 CONSTRAINT [PK__Unidades__3214EC070496D041] PRIMARY KEY CLUSTERED 
(
	[UnidadMedidaId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[usuarios]    Script Date: 7/7/2023 8:50:46 p.�m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[usuarios](
	[UsuarioId] [int] IDENTITY(1,1) NOT NULL,
	[Nombre] [varchar](200) NULL,
	[Apellido] [varchar](200) NULL,
	[User] [varchar](50) NULL,
	[Pass] [varchar](200) NULL,
	[Correo] [varchar](200) NULL,
	[Estado] [bit] NULL,
 CONSTRAINT [PK__usuarios__48BE79C9227855BB] PRIMARY KEY CLUSTERED 
(
	[UsuarioId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Orden_de_compra] ADD  CONSTRAINT [FK__Orden_de___Artic__3F466844] FOREIGN KEY([Articulo])
REFERENCES [dbo].[Articulos] ([ArticuloId])
GO
ALTER TABLE [dbo].[Orden_de_compra] ADD  CONSTRAINT [FK__Orden_de___Unida__403A8C7D] FOREIGN KEY([Unidad_de_medida])
REFERENCES [dbo].[Unidades_de_medidas] ([UnidadMedidaId])

GO
ALTER TABLE [dbo].[Orden_de_compra] ADD  CONSTRAINT [FK__Orden_de___Usuar__5812160E] FOREIGN KEY([UsuarioId])
REFERENCES [dbo].[usuarios] ([UsuarioId])
GO
ALTER TABLE [dbo].[Articulos] ADD FOREIGN KEY([UnidadMedidaId])
REFERENCES [dbo].[Unidades_de_medidas] ([UnidadMedidaId])
GO
USE [master]
GO
ALTER DATABASE [DBCompras] SET  READ_WRITE 
GO
